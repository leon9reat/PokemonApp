package com.medialink.ui.detail

interface IDetailActivity {

}