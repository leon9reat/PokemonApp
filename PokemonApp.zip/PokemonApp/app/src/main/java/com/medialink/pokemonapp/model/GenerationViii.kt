package com.medialink.pokemonapp.model


import com.google.gson.annotations.SerializedName

data class GenerationViii(
    @SerializedName("icons")
    val icons: IconsX?
)