package com.medialink.ui.main

import com.medialink.pokemonapp.model.Result

interface IMainActivity {
    fun onItemClick(result: Result)
}